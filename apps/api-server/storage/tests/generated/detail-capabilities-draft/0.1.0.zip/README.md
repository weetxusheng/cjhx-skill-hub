# Detail Capabilities Draft

body
