# 后端开发规范

> 代码书写细则（route/service/repository 模板、异常处理、测试写法）统一以 `docs/20-engineering/backend-code-spec.md` 为执行标准。

## 分层约束
### Route
- 负责鉴权、参数解析、返回封装
- 可做：依赖注入、轻量查询参数处理
- 禁止：复杂 SQL、跨实体事务编排、缓存失效策略

### Service
- 负责业务状态机、事务、审计、缓存失效、写模型
- 必须承载：
  - 上传
  - 提审
  - 审核
  - 发布
  - 回滚
  - 授权变更
  - 统计聚合写入

### Repository
- 负责复杂读取、聚合、工作台列表查询
- 禁止：状态流转、副作用

## 请求处理链路（推荐）
- `route`：参数校验 + 权限依赖 + request_id 注入
- `service`：业务规则判断 + 事务边界 + 审计写入 + 缓存失效
- `repository`：读取与写入落库
- `schema`：统一响应序列化
- 任一层出现业务冲突都要返回可追踪错误信息（含对象 id 与冲突原因）

## 鉴权清单
- 全局权限由 `require_permissions(...)` 控制
- 单 skill 权限由 `ensure_skill_scopes(...)` 控制
- 新增 skill 相关接口时，必须同时考虑：
  - 是否需要后台全局权限
  - 是否需要 skill 级授权
  - 是否需要状态检查

## capability 下发约定
- 涉及“按钮可用性”的详情接口必须返回 capability，至少包含：
  - `can_edit`
  - `can_submit`
  - `can_approve`
  - `can_reject`
  - `can_publish`
  - `can_archive` / `can_rollback`（按场景）
- capability 由后端统一计算，前端只消费，不再自行拼条件
- capability 计算必须同时考虑：
  - 全局权限
  - skill scope
  - 当前状态机阶段
  - 角色职责（如 reviewer/publisher）

## 状态机要求
- 非法流转统一返回 `409 Conflict`
- 审核拒绝必须要求 comment
- 发布和回滚必须放在事务中执行
- 发布成功后必须维护：
  - `skills.current_published_version_id`
  - `skills.latest_version_no`
  - `skills.published_at`
- 回滚后前台详情和列表读取的线上版本必须立即变化

## 事务与幂等细节
- 以下动作必须放在同一事务：`approve`、`reject`、`publish`、`rollback`、授权批量变更
- 对“重复提交同一动作”必须有幂等保护：
  - 重复发布同一版本 -> 返回可读 `409`
  - 重复提审同一草稿 -> 返回可读 `409`
- 事务内更新顺序建议：状态变更 -> 主档冗余字段 -> 审计日志 -> 提交
- 提交后再执行缓存失效，避免“缓存已删但事务回滚”

## 审计要求
- 后台所有写操作必须写 `audit_logs`
- 至少记录：
  - actor
  - action
  - target_type
  - target_id
  - request_id
  - before_json
  - after_json
- `before_json/after_json` 只记录与本次动作相关的字段，避免写入过大冗余数据
- 审计 action 命名统一使用 `domain.entity.action`（例如：`skill.version.publish`）

## 缓存要求
- 可缓存：
  - 公开分类列表
  - 公开技能详情
  - 高频只读列表
- 必须失效的场景：
  - publish
  - rollback
  - skill 主档编辑
  - 点赞/收藏变更
  - 影响公开展示的数据更新

## 错误响应细节
- 错误响应必须稳定包含：`code`、`message`、`request_id`
- 对前端可直接展示的冲突错误，`message` 要可读且可执行（告诉用户下一步）
- `404` 需要区分“对象不存在”与“对象不可见”，但对外文案保持安全最小披露

## 错误码约定
- `400`：请求内容不合法
- `401`：未登录或 token 失效
- `403`：权限不足
- `404`：对象不存在或不对当前用户公开
- `409`：状态冲突、重复版本、非法流转

## Skill 相关接口新增时的必查项
1. 全局权限是否正确
2. skill 级授权是否正确
3. 当前版本状态是否允许
4. 是否需要写 `audit_logs`
5. 是否需要清缓存
6. 是否需要同步更新冗余统计或主档字段
7. 是否需要新增/更新 capability 字段
8. 是否补了状态机与权限矩阵测试

## 代码实现细则（函数级）
### Route 层写法（FastAPI）
- 每个接口函数只做四件事：
  - 解析参数（path/query/body）
  - 调用依赖鉴权（`require_permissions` / `ensure_skill_scopes`）
  - 调用单一 service 方法
  - 返回统一响应对象
- Route 函数禁止：
  - 直接写 SQL
  - 拼装跨实体事务
  - 直接改缓存
- 推荐函数签名顺序：`request` -> path 参数 -> query 参数 -> body -> `db` -> `current_user`

### Service 层写法
- Service 方法命名统一：`verb_domain_object`（如 `approve_skill_version`）
- Service 方法应显式声明输入 DTO 与返回 DTO，禁止返回裸 ORM 对象给 route
- 事务边界必须在 service，推荐模式：
  - 读取并校验前置状态
  - 执行业务变更
  - 记录审计
  - `commit`
  - 提交后执行缓存失效
- 对并发敏感状态流转，读取时使用行级锁（如 `SELECT ... FOR UPDATE` 或 ORM 等价能力）

### Repository 层写法
- Repository 方法命名体现查询语义，不出现业务动作词（如 `approve/reject/publish`）
- 复杂查询必须封装在 repository，route/service 不拼接多表 SQL
- 查询分页统一返回：`items`, `total`, `page`, `page_size`
- 禁止 repository 里调用审计写入、消息推送、缓存失效等副作用逻辑

## 异常与响应映射（代码约束）
- 推荐定义领域异常并统一映射 HTTP：
  - `ValidationError` -> `400`
  - `AuthError` -> `401`
  - `PermissionDenied` -> `403`
  - `NotFoundError` -> `404`
  - `StateConflictError` -> `409`
- 业务代码中优先抛领域异常，不直接在 service 内 `raise HTTPException`
- 全局异常处理器必须补充 `request_id` 到响应，便于审计串联

## Schema 与类型约束
- 输入输出 schema 分离：`Create/Update` 与 `Detail/ListItem` 不混用
- 对外响应字段命名稳定，禁止随实现重构频繁改名
- 时间字段统一返回 ISO8601（UTC）
- 枚举字段使用显式 `Enum` 类型，禁止魔法字符串散落在 service

## 审计日志落地模板（代码要求）
- 每个后台写动作必须有统一审计调用，至少包含：
  - `actor_id`
  - `action`
  - `target_type`
  - `target_id`
  - `request_id`
  - `before_json`
  - `after_json`
- `before_json/after_json` 只放关键业务字段，避免整对象序列化
- 审计调用放在事务内，保证“业务成功 <-> 审计成功”一致性

## 数据库访问与性能约束
- 工作台列表接口默认禁止 N+1 查询，必须一次性拿到列表展示必需摘要字段
- 高频筛选字段（状态、时间、分类、负责人）变更前必须评估索引
- 大列表查询默认限制 `page_size` 上限（如 100），避免意外全表扫描
- 不允许把 JSON 大字段无筛选地放进列表接口返回

## 缓存实现细节
- 缓存 key 命名建议：`{domain}:{resource}:{id}:{variant}`
- 失效优先级：先提交事务，再删缓存
- 禁止用“超短 TTL”替代明确失效逻辑
- 发布/回滚后，必须清理：
  - 公开技能详情缓存
  - 公开技能列表缓存
  - 相关统计卡片缓存（若有）

## 测试代码细则
- 新增或修改 service 时，至少补：
  - 成功路径测试 1 条
  - 权限拒绝测试 1 条
  - 状态冲突测试 1 条
- 命中状态机改动时必须补“完整链路测试”（draft -> submitted -> approved -> published）
- 命中授权改动时必须补“权限矩阵测试”（角色 + scope 组合）
- 命中统计改动时必须补“明细汇总 == 冗余字段”断言

## 目录与命名约定（后端）
- `app/api/routes/*`：按能力域拆文件，单文件过大时按子域拆分
- `app/services/*`：一个文件一个核心域，避免“万能 service”
- `app/repositories/*`：按查询域拆分，不跨域耦合
- 函数命名使用动词开头；布尔返回命名使用 `is_/has_`
