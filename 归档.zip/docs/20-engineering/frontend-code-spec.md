# 前端代码规范（代码级）

## 目标
- 本文用于约束“具体代码怎么写”，与 `frontend-guide.md`（架构约束）和 `ui-interaction-spec.md`（视觉交互）配套。
- 机器门禁以 `pnpm lint`、`eslint`、`infra/scripts/check-code-quality.sh` 为准；超阈值文件必须登记到 `code-quality-debt-register.md`。

## 文件与命名
- 组件文件：`PascalCase.tsx`，例如 `ReviewVersionDetailModal.tsx`
- hooks 文件：`useXxx.ts`，例如 `useReviewFilters.ts`
- 工具与 API 文件：`camelCase.ts`，例如 `portalPermissions.ts`
- 页面组件必须放 `src/pages/**`，禁止把页面逻辑塞进 `src/components/**`
- 一个文件一个默认导出组件（页面可默认导出，通用组件优先命名导出）

## React 组件写法
- 组件长度建议不超过 `250` 行；超过必须拆子组件或 hooks
- hooks 顺序固定：`state -> memo -> callback -> effect`，禁止条件调用 hooks
- `useEffect` 必须写“触发条件注释”（复杂逻辑），并最小化依赖
- 事件处理函数命名统一：`handleXxx`
- 布尔状态命名统一：`isXxx` / `hasXxx` / `canXxx`

## TypeScript 约束
- 禁止 `any`（测试桩除外，需加注释说明）
- API 响应必须定义类型，禁止 `as unknown as`
- 组件 props 必须显式类型，禁止隐式 `children: any`
- 字符串状态禁止散落字面量，统一抽为 union 或 enum

## 数据请求规范（React Query）
- `queryKey` 必须包含：资源名 + token + 分页 + 筛选 + 排序
- `queryFn` 内禁止读组件外可变全局状态
- 写操作统一 `useMutation`，成功后必须 `invalidateQueries`
- 页面首屏关键 query 必须有 loading / error / empty 分支

## 路由与权限代码约束
- 路由可达性判断统一封装函数，禁止在 JSX 内写复杂权限表达式
- “菜单显示”和“路由可达”必须共用同一权限判定函数，避免口径分叉
- 自动恢复路径只允许执行一次，且不得覆盖用户主动导航

## 表单代码约束
- 表单提交函数命名：`handleSubmitXxx`
- 提交前做前端最小校验；业务规则校验以后端为准
- 提交中按钮必须 `loading`，防止重复点击
- 错误展示优先字段级，其次全局 `message.error`

## 组件复用与边界
- 复用条件：同语义出现 >= 2 次即抽组件
- 页面私有组件放同目录 `_components` 或同文件底部（不跨页暴露）
- 禁止在通用组件里耦合页面路由与业务状态机

## 样式与 CSS 约束
- 优先复用现有类名与 token；禁止新增“只为一个页面服务”的全局污染类
- 样式命名统一 kebab-case，且必须有页面前缀（如 `admin-reviews-*`）
- 禁止使用 `!important`（紧急修复除外，需补 TODO）

## 日志与调试
- 禁止提交 `console.log`
- 可保留 `console.error` 仅用于边界错误兜底（需带上下文）
- 临时调试代码必须在提交前删除

## 前端测试代码约束
- E2E 选择器优先 `id`，其次 `data-testid`，禁止依赖中文文案
- 每个关键页面至少覆盖：
  - 可打开
  - 核心动作可执行
  - 权限不足时行为正确
- 回归用例命名：`should_<expected>_when_<condition>`

## 禁止事项（硬规则）
- 禁止在 render 中发请求
- 禁止把后端返回对象直接放入全局 store 不做裁剪
- 禁止“接口失败后静默吞错”
- 禁止“权限不足直接 return null”导致页面空白
