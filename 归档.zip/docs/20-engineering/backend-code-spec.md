# 后端代码规范（代码级）

## 目标
- 本文定义后端“具体实现细节”，与 `backend-guide.md`（架构与流程）互补。
- 机器门禁以 `pnpm lint`、`ruff check`、`infra/scripts/check-code-quality.sh` 为准；超阈值文件必须登记到 `code-quality-debt-register.md`。

## Python 与文件组织
- Python 版本特性按仓库当前运行版本使用，不做跨版本语法混用
- 单文件建议不超过 `400` 行；超过需拆分子模块
- 导入顺序：标准库 -> 三方库 -> 本地模块；组间空一行
- 常量统一大写并集中在文件顶部

## Route 代码模板约束
- Route 函数最大职责：参数解析 + 权限依赖 + service 调用 + 响应包装
- Route 内禁止：
  - 数据库 session commit/rollback
  - 业务状态流转
  - 缓存删改
- 每个 route 需定义清晰 `response_model`（或等价 schema 输出）

## Service 代码模板约束
- 方法命名：`verb_object`（如 `publish_version`）
- 方法结构固定：
  - `load`：加载对象
  - `guard`：权限/状态校验
  - `mutate`：执行业务变更
  - `audit`：审计落库
  - `commit`
  - `post_commit`：缓存失效/异步通知
- 一个 service 方法只做一个业务动作，禁止“万能入口 + action switch”

## Repository 代码模板约束
- Repository 仅关心数据存取，不做业务判断
- 查询函数命名应表达筛选维度，如 `list_pending_reviews_by_category`
- 返回值禁止泄露 ORM 内部状态对象，统一返回 schema 或 DTO
- 多表查询必须显式选择字段，禁止 `select *`

## 数据库事务与锁
- 状态流转相关操作默认在事务中执行
- 并发争用点（审核、发布、回滚、授权批改）必须加锁或做版本校验
- 禁止在事务中执行外部 I/O（HTTP、文件系统、慢缓存操作）

## 错误处理代码约束
- service 抛领域异常，route/异常中间件做 HTTP 映射
- 错误 message 必须可给前端直出（避免“unknown error”）
- 日志必须包含 `request_id`、`actor_id`、关键对象 id
- 禁止裸 `except Exception` 吞错；必须记录并转义为可追踪异常

## 审计代码约束
- 写接口必须调用统一 `audit_log` helper，禁止各处手写散乱审计
- action 命名遵循 `domain.entity.action`
- before/after 只记录必要字段，禁止记录敏感凭据与大体积正文

## 性能约束
- 列表接口默认分页，`page_size` 必须有上限保护
- 访问热点接口要有 explain/索引评估记录（PR 描述即可）
- 禁止在循环内执行数据库查询（N+1）
- 统计接口必须优先复用已有聚合或明细索引

## 缓存约束
- 缓存写入与失效统一走 helper，禁止业务代码分散拼 key
- key 命名：`{domain}:{resource}:{id}:{view}`
- 失效时机：事务提交后
- 禁止仅靠 TTL 兜底关键一致性问题

## 安全约束
- 输入参数必须经过 schema 校验
- 严禁直接拼接 SQL 字符串（必须参数化）
- 权限校验失败不暴露内部实体存在性细节
- 下载/导出接口必须做权限 + 范围双校验

## 测试代码规范
- 每个新增 service 至少三类测试：
  - happy path
  - permission denied
  - state conflict
- 每个关键 route 至少一条 contract 测试（字段、状态码、错误体）
- 测试函数命名：`test_<action>_<expected>_when_<condition>`
- fixture 设计要求：
  - 最小化数据集
  - 明确角色与权限
  - 避免共享可变全局状态

## 禁止事项（硬规则）
- 禁止在 route 里直接操作 ORM 模型并提交
- 禁止把权限判断仅放前端，不在后端二次校验
- 禁止把统计口径逻辑散落在多个 service 且无统一定义
- 禁止“改状态不写审计”
