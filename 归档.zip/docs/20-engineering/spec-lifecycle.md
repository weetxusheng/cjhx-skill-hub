# 规范生命周期

## 目的
本文件定义 Skill Hub 的规范如何在迭代过程中被补充、修订和落地，避免出现“代码变了，文档没跟上”或“计划文件替代正式规范”的情况。

## 哪些变更必须补规范
- 架构边界变化
- 权限模型变化
- 审核 / 待发布 / 回滚状态机变化
- 数据库 schema、索引、约束、seed 变化
- API 字段、分页、错误语义变化
- skill 统计口径和可见范围变化
- 工作台推荐操作路径变化
- 发布、恢复、本地开发流程变化
- lint、代码细节硬规则、文件拆分阈值与例外清单变化

## 先改文档还是先改代码
- 高风险规则变更：
  - 权限
  - 状态机
  - API 契约
  - 统计口径
  先更新或同步更新文档，再实现代码
- 低风险实现细节：
  - 样式
  - 轻微文案
  - 非规则性重构
  可以先改代码，但若触及规范边界，必须补文档

## 补到哪一层文档
- 改系统结构、边界、模块关系：
  - `docs/10-architecture/`
- 改开发方式、目录规则、测试和发布门禁：
  - `docs/20-engineering/`
- 改 lint、文件拆分阈值、代码质量例外：
  - `docs/20-engineering/code-quality-gates.md`
  - `docs/20-engineering/code-quality-debt-register.md`
- 改业务流、工作台路径、统计口径、授权职责：
  - `docs/30-product-flows/`
- 改命令、启动、恢复、发布操作：
  - `docs/40-runbooks/` 或 `docs/deploy/`
- 改 AI / 协作执行方式：
  - `AGENTS.md` 和 `docs/50-prompts/`

## 责任分工
- 实现者：
  - 识别变更类型
  - 更新代码、测试和文档
- 评审者：
  - 检查是否命中 `doc-update-matrix`
  - 检查正式规范与实现是否一致
- 发布执行者：
  - 运行 `release-check.sh`
  - 确认规范、测试、构建和脏文件检查通过

## 完成定义
一次变更只有在以下条件都满足时才算完成：
- 代码已修改
- 对应测试已补或已确认不需要新增
- 命中的正式规范文档已更新
- `docs/skill-hub-master-plan.md` 如涉及阶段推进已同步记录
- `infra/scripts/release-check.sh` 可通过

## 禁止事项
- 不得只更新 `docs/skill-hub-master-plan.md` 来代替正式规范更新
- 不得让 `docs/50-prompts/` 承担事实来源职责
- 不得把未讨论清楚的业务规则只藏在代码里
- 不得新增代码质量例外而不登记 debt register 和 allowlist
