# 代码质量门禁

## 目的
本文件定义 Skill Hub 的代码细节门禁，解决“规范写了，但仓库不会拦”的问题。以后代码质量不只靠评审口头提醒，而是通过脚本、lint 和例外登记共同约束。

## 门禁组成
Skill Hub 当前采用三层门禁：
- 静态检查：
  - 前端 `eslint`
  - 后端 `ruff check`
- 代码质量脚本：
  - `infra/scripts/check-code-quality.sh`
- 发布级检查：
  - `infra/scripts/release-check.sh`

## 当前硬规则
### 前端
- 禁止 `console.log`
- 禁止组件直接 `return null` 导致空白页或空白区块
- 默认单文件阈值：`250` 行
- 若超阈值，必须：
  - 先拆分；或
  - 进入 `code-quality-debt-register.md` 和 allowlist

### 后端
- 默认应用源码单文件阈值：`400` 行
- 默认测试文件阈值：`600` 行
- 后端 lint 统一走 `ruff check`
- 新增未使用导入、未使用变量、明显静态问题不允许进入主干

## 例外机制
- 例外不是“默认允许”，而是技术债登记
- 出现以下情况才允许登记例外：
  - 正在拆分过程中的存量大文件
  - 高风险重构前的暂存过渡
  - 测试文件为了保持链路完整暂时超长
- 新增例外时必须同时更新：
  - `docs/20-engineering/code-quality-debt-register.md`
  - `infra/config/code-quality-allowlist.txt`
- 例外被清理后，必须同一轮移除登记和 allowlist

## 默认执行顺序
1. 写代码
2. `pnpm local:ensure`
3. `pnpm lint`
4. 按 `feature-test-playbook.md` 选择 `L1/L2/L3`
5. 运行对应测试
6. 最终运行 `pnpm release:check`

## 评审关注点
- 是否引入新的长文件、重复实现或跨层耦合
- 是否新增了本应抽离的页面私有组件
- 是否只修了业务逻辑，却没有消除明显的代码细节退化
- 是否新增了 allowlist 项但没有写清退出条件

## 完成定义
- `pnpm lint` 通过
- `infra/scripts/check-code-quality.sh` 通过
- 若存在例外，登记与 allowlist 一致
- 代码评审能明确判断这是“合规实现”还是“带债交付”
